package com.example.musicapp.data.model;

import androidx.room.ColumnInfo;
import androidx.room.Entity;
import androidx.room.Index;
import androidx.room.PrimaryKey;

import com.google.gson.annotations.Expose;
import com.google.gson.annotations.SerializedName;

/**
 * Room permite el mapeado objeto-relacional, por lo que nos permite mapear esta
 * clase java a una tabla relacional. Ademas se ha creado un índice con la columna
 * username para poder acelerar las consultas en la base de datos y este sera único
 **/

@Entity(tableName = "playlist", indices = {@Index(name = "search_playlist", value = {"id"}, unique = true)})
public class Playlist {

    @SerializedName("idPlaylist")
    @Expose
    @PrimaryKey
    @ColumnInfo(name = "idPlaylist")
    private String idPlaylist;
    @SerializedName("namePlaylist")
    @Expose
    @ColumnInfo(name = "namePlaylist")
    private String namePlaylist;
    @SerializedName("idUser")
    @Expose
    @PrimaryKey
    @ColumnInfo(name = "idUser")
    private long idUser;
    @SerializedName("idSong")
    @Expose
    @PrimaryKey
    @ColumnInfo(name = "idSong")
    private String idSong;

    public Playlist(String idPlaylist,String namePlaylist, long idUser, String idSong) {
        this.idPlaylist = idPlaylist;
        this.namePlaylist = namePlaylist;
        this.idUser = idUser;
        this.idSong = idSong;
    }

    public String getIdPlaylist() {return idPlaylist;}
    public void setIdPlaylist(String idPlaylist) {this.idPlaylist = idPlaylist;}

    public long getIdUser() {return idUser;}
    public void setIdUser(long idUser) {this.idUser = idUser;}

    public String getIdSong() {return idSong;}
    public void setIdSong(String idSong) {this.idSong = idSong;}

    public String getNamePlaylist() {return namePlaylist;}

    public void setNamePlaylist(String namePlaylist) {this.namePlaylist = namePlaylist;}
}
