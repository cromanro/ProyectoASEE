package com.example.musicapp.data;

import com.example.musicapp.data.model.Song;
import java.util.List;
import retrofit2.Call;
import retrofit2.http.GET;

/**
 * Clase que hace una petición de GET a la ruta de la api, que en este caso sera al archivo Musica.json
 * de la carpera Musica del repositorio de cromanro y que devuelve la lista de canciones.
 **/
public interface GitHubService {
    //@GET("cromanro/Musica/main/Musica.json")
    @GET("cromanro/Musica/Musica.json")
    Call<List<Song>> listSongs();
}