package com.example.musicapp;

import android.app.Application;

/**
 * Objeto MusicApp que hereda de Aplicacion.
 * Este será el primer objeto que se cree al iniciar la aplicacion.
 * Ademas sera utilizado como punto comun para el contenedor de dependencias
 * AppContainer.
 **/

public class MusicApp extends Application {

    public AppContainer appContainer;

    /**
     * Creamos el AppContainer de forma dinamica para poder pasarle el contexto
     * para despues poder pasarselo a las bases de datos de room.
     **/
    @Override
    public void onCreate() {
        super.onCreate();
        appContainer = new AppContainer(this);
    }
}