package com.example.musicapp.data.roomdb;

import android.content.Context;

import androidx.room.Database;
import androidx.room.Room;
import androidx.room.RoomDatabase;

import com.example.musicapp.data.model.Song;
import com.example.musicapp.data.model.User;


/**
 * Base de datos de Room la cual almacenara toda la informacion de las canciones.
 */
@Database(entities = {User.class, Song.class}, version = 1)
public abstract class MusicDB extends RoomDatabase {
    private static MusicDB instance;

    /**
     * Obtener la instancia de la BD (Singleton)
     */
    public static MusicDB getInstance(Context context) {
        if (instance == null)
            instance = Room.databaseBuilder(context, MusicDB.class, "prueba1.db").build();
        return instance;
    }

    /**
     * Obtener el DAO de usuarios
     */
    public abstract UserDAO getUserDAO();

    /**
     * Obtener el DAO de canciones
     */
    public abstract SongDAO getSongDAO();

    /**
     * Obtener el DAO de canciones
     */
    public abstract PlaylistDAO getPlaylistDAO();
}
