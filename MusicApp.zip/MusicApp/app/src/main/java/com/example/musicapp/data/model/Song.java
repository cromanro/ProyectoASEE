package com.example.musicapp.data.model;

import androidx.room.ColumnInfo;
import androidx.room.Entity;
import androidx.room.Index;
import androidx.room.PrimaryKey;

import com.google.gson.annotations.Expose;
import com.google.gson.annotations.SerializedName;

/**
 * Room permite el mapeado objeto-relacional, por lo que nos permite mapear esta
 * clase java a una tabla relacional. Ademas se ha creado un índice con la columna
 * username para poder acelerar las consultas en la base de datos y este sera único
 **/
@Entity(tableName = "song", indices = {@Index(name = "search_song", value = {"id", "title"}, unique = true)})
public class Song {

    @SerializedName("id")
    @Expose
    @PrimaryKey
    @ColumnInfo(name = "id")
    private String id;
    @SerializedName("title")
    @Expose
    @ColumnInfo(name = "title")
    private String title;
    @SerializedName("platform")
    @Expose
    @ColumnInfo(name = "platform")
    private String platform;
    @SerializedName("artist")
    @Expose
    @ColumnInfo(name = "artist")
    private String artist;
    @SerializedName("artistLink")
    @Expose
    @ColumnInfo(name = "artistLink")
    private String artistLink;
    @SerializedName("album")
    @Expose
    @ColumnInfo(name = "album")
    private String album;
    @SerializedName("albumLink")
    @Expose
    @ColumnInfo(name = "albumLink")
    private String albumLink;
    @SerializedName("duration")
    @Expose
    @ColumnInfo(name = "duration")
    private Float duration;

    public Song(String id, String title, String platform, String artist, String artistLink, String album, String albumLink, Float duration) {
        this.id = id;
        this.title = title;
        this.platform = platform;
        this.artist = artist;
        this.artistLink = artistLink;
        this.album = album;
        this.albumLink = albumLink;
        this.duration = duration;
    }

    public String getId() {return id;}
    public void setId(String id) {this.id = id;}

    public String getTitle() {return title;}
    public void setTitle(String title) {this.title = title;}

    public String getPlatform() {return platform;}
    public void setPlatform(String platform) {this.platform = platform;}

    public String getArtist() {return artist;}
    public void setArtist(String artist) {this.artist = artist;}

    public String getArtistLink() {return artistLink;}
    public void setArtistLink(String artistLink) {this.artistLink = artistLink;}

    public String getAlbum() {return album;}
    public void setAlbum(String album) {this.album = album;}

    public String getAlbumLink() {return albumLink;}
    public void setAlbumLink(String albumLink) {this.albumLink = albumLink;}

    public Float getDuration() {return duration;}
    public void setDuration(Float duration) {this.duration = duration;}
}
