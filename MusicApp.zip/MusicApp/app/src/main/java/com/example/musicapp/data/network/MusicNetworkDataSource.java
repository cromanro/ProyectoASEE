package com.example.musicapp.data.network;

import android.util.Log;

import androidx.lifecycle.LiveData;
import androidx.lifecycle.MutableLiveData;

import com.example.musicapp.data.executor.AppExecutors;
import com.example.musicapp.data.executor.OnMusicLoadedListener;
import com.example.musicapp.data.model.Song;

import java.util.List;

/*
 * Clase que obtiene los datos necesarios para el repository
 */
public class MusicNetworkDataSource {

    private static final String LOG_TAG = MusicNetworkDataSource.class.getSimpleName();
    private static MusicNetworkDataSource sInstance;
    private final MutableLiveData<Song[]> mSongsDownload;

    private MusicNetworkDataSource() {
        mSongsDownload = new MutableLiveData<>();
    }

    /*
     * Metodo que obtiene la instancia del Singleton
     */
    public synchronized static MusicNetworkDataSource getInstance() {
        Log.d(LOG_TAG, "Getting the network data source");
        if (sInstance == null) {
            sInstance = new MusicNetworkDataSource();
            Log.d(LOG_TAG, "Made new network data source");
        }
        return sInstance;
    }

    /*
     * Método para obtener las canciones de la API.
     */
    public LiveData<Song[]> getSongsActual() {
        return mSongsDownload;
    }

    /**
     * Cargamos las canciones actuales de la API.
     */
    public void cargarSongs(){
        Log.d(LOG_TAG, "Fetch songs started");
        AppExecutors.getInstance().networkIO().execute(new MusicNetworkLoaderRunnable(new OnMusicLoadedListener() {
            @Override
            public void onSongsLoader(List<Song> songs) {
                mSongsDownload.postValue(songs.toArray(new Song[0]));
            }
        }));
    }

}
