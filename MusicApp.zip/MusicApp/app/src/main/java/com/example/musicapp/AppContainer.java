package com.example.musicapp;

import android.content.Context;

import com.example.musicapp.data.MusicRepository;
import com.example.musicapp.data.network.MusicNetworkDataSource;
import com.example.musicapp.data.roomdb.MusicDB;


/**
 * Contenedor manual de depencias para el acceso a datos desde el repository (BD y API) y los ViewModels
 **/

public class AppContainer {

    private MusicDB musicDB;//Base de datos de Room
    private MusicNetworkDataSource musicNetworkDataSource;//API de Network
    public MusicRepository musicRepository;//Repository

    public AppContainer(Context context) {
        musicDB = MusicDB.getInstance(context);
        musicNetworkDataSource = MusicNetworkDataSource.getInstance();
        musicRepository = MusicRepository.getInstance(musicDB.getUserDAO(), musicDB.getSongDAO(), musicDB.getPlaylistDAO(), musicNetworkDataSource);
    }
}
