package com.example.musicapp.data.roomdb;

import androidx.lifecycle.LiveData;
import androidx.room.Dao;
import androidx.room.Insert;
import androidx.room.Query;

import com.example.musicapp.data.model.Playlist;

import java.util.List;

import static androidx.room.OnConflictStrategy.REPLACE;

@Dao
public interface PlaylistDAO {

    /**
     * Añade todas las canciones de la playlist y en caso de haber conflicto se reemplazan
     **/
    @Insert(onConflict = REPLACE)
    void bulkInsert(List<Playlist> playlists);

    /**
     * Añade una playlist
     **/
    @Insert
    void insertPlaylist(Playlist playlist);

    /**
     * Devolver en un LiveData la lista de todas las canciones de la playlist para observarla
     **/
    @Query("SELECT * FROM playlist")
    LiveData<List<Playlist>> listAllPlaylist();

    /**
     * Devolver en un LiveData la lista de todas las canciones de la playlist de un usuario para observarla
     **/
    @Query("SELECT * FROM playlist WHERE idUser LIKE :idUser")
    LiveData<List<Playlist>> listAllPlaylistByUser(long idUser);

    /**
     * Devolver en un LiveData una cancion de la playlist buscada por su id
     **/
    @Query("SELECT * FROM playlist WHERE idPlaylist LIKE :idPlaylist")
    LiveData<Playlist> searchById(String idPlaylist);

    /**
     * Borrar todas las canciones de una playlist de un usuario de la BD
     **/
    @Query("DELETE FROM playlist WHERE idUser LIKE :idUser")
    int deleteAllPlaylistByUser(long idUser) ;

    /**
     * Borrar una cancion de la playlist de un usuario de la BD
     **/
    @Query("DELETE FROM playlist WHERE idUser LIKE :idUser AND idPlaylist LIKE :idPlaylist AND idSong LIKE :idSong")
    int deleteSongPlaylist(String idPlaylist,long idUser,String idSong) ;

    /**
     * Borrar un playlist determinada
     **/
    @Query("DELETE FROM playlist WHERE idUser LIKE :idUser AND idPlaylist LIKE :idPlaylist")
    int deletePlaylistByUser(String idPlaylist,long idUser);

}
