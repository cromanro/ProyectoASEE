package com.example.musicapp.data.roomdb;

import androidx.lifecycle.LiveData;
import androidx.room.Dao;
import androidx.room.Insert;
import androidx.room.Query;

import com.example.musicapp.data.model.Song;

import java.util.List;

import static androidx.room.OnConflictStrategy.REPLACE;

@Dao
public interface SongDAO {

    /**
     * Añadir todas las canciones y en caso de haber conflicto se reemplazan
     **/
    @Insert(onConflict = REPLACE)
    void bulkInsert(List<Song> songs);

    /**
     * Devolver en un LiveData la lista de todas las canciones para observarla
     **/
    @Query("SELECT * FROM song")
    LiveData<List<Song>> listAllSongs();

    /**
     * Devolver en un LiveData una cancion buscada por su id
     **/
    @Query("SELECT * FROM song WHERE id LIKE :id")
    LiveData<Song> searchById(String id);

    /**
     * Borrar todas las canciones de la BD
     **/
    @Query("DELETE FROM song")
    int deleteAllSongs();

}
