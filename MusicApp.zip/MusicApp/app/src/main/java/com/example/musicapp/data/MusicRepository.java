package com.example.musicapp.data;

import android.util.Log;

import androidx.lifecycle.LiveData;
import androidx.lifecycle.MutableLiveData;
import androidx.lifecycle.Observer;
import androidx.lifecycle.Transformations;

import com.example.musicapp.data.executor.AppExecutors;
import com.example.musicapp.data.model.Playlist;
import com.example.musicapp.data.model.Song;
import com.example.musicapp.data.model.User;
import com.example.musicapp.data.network.MusicNetworkDataSource;
import com.example.musicapp.data.roomdb.PlaylistDAO;
import com.example.musicapp.data.roomdb.SongDAO;
import com.example.musicapp.data.roomdb.UserDAO;

import java.util.Arrays;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.regex.Matcher;
import java.util.regex.Pattern;



/**
 * Handles data operations in Sunshine. Acts as a mediator between {@link com.example.musicapp.data.network.MusicNetworkDataSource}
 * and {@link com.example.musicapp.data.roomdb.SongDAO}
 */
public class MusicRepository {
    private static final String LOG_TAG = MusicRepository.class.getSimpleName();

    // For Singleton instantiation
    private static MusicRepository sInstance;

    //DAO de la BD
    private final SongDAO mSongDAO;
    private final UserDAO mUserDAO;
    private final PlaylistDAO mPlaylistDAO;

    //Fuente de datos remota
    private final MusicNetworkDataSource mSongNetworkDataSource;
    private final AppExecutors mExecutors = AppExecutors.getInstance();

    //Calcular la actualización de productos
    private final Map<String, Long> lastUpdateTimeMillisMap = new HashMap<>();
    private static final long MIN_TIME_FROM_LAST_FETCH_MILLIS = 30000;

    //LiveData
    private final MutableLiveData<String> idFilterSong = new MutableLiveData<String>();
    private final MutableLiveData<Long> idFilterUser = new MutableLiveData<Long>();
    private final MutableLiveData<String> idFilterPlaylist = new MutableLiveData<String>();

    /*
     * Mientras existan los productos observamos el LiveData.
     * Si ese LiveData cambia, se actualiza la base de datos.
     */
    private MusicRepository(UserDAO userDAO, SongDAO songDAO, PlaylistDAO playlistDAO, MusicNetworkDataSource songNetworkDataSource) {
        mUserDAO = userDAO;
        mSongDAO = songDAO;
        mPlaylistDAO = playlistDAO;
        mSongNetworkDataSource= songNetworkDataSource;

        LiveData<Song[]> networkData = mSongNetworkDataSource.getSongsActual();
        networkData.observeForever(new Observer<Song[]>() {
            @Override
            public void onChanged(Song[] songFromNetwork) {
                mExecutors.diskIO().execute(() -> {
                    //Se borran las canciones de la cache si existe alguna cancion nueva.
                    if (songFromNetwork.length > 0) {
                        mSongDAO.deleteAllSongs();
                    }
                    mSongDAO.bulkInsert(Arrays.asList(songFromNetwork));
                    Log.d(LOG_TAG, "New values of songs inserted in Room");
                });
            }
        });
    }

    /**
     * Obtenemos la instancia del repositorio. Si aun no se ha creado la creamos.
     **/
    public synchronized static MusicRepository getInstance(UserDAO userDAO, SongDAO songDAO,PlaylistDAO playlistDAO, MusicNetworkDataSource songNetworkDataSource) {
        Log.d(LOG_TAG, "Getting the repository");
        if (sInstance == null) {
            sInstance = new MusicRepository(userDAO, songDAO, playlistDAO, songNetworkDataSource);
            Log.d(LOG_TAG, "Made new repository");
        }
        return sInstance;
    }

    /**
     * Obtener las canciones actuales de la BD en un LiveData
     **/

    public LiveData<List<Song>> getSongsActual() {
        if (isCargarCanciones()) {
            doCargarCanciones();
        }
        return mSongDAO.listAllSongs();
    }

    /**
     * Checks if we have to update the songs data.
     * @return Whether a fetch is needed
     */
    private boolean isCargarCanciones() {
        Long lastFetchTimeMillis = lastUpdateTimeMillisMap.get("1");
        lastFetchTimeMillis = lastFetchTimeMillis == null ? 0L : lastFetchTimeMillis;
        long timeFromLastFetch = System.currentTimeMillis() - lastFetchTimeMillis;
        return timeFromLastFetch > MIN_TIME_FROM_LAST_FETCH_MILLIS;
    }

    /**
     * Descargar las canciones de la fuente de datos remota
     **/
    private void doCargarCanciones(){
        Log.d(LOG_TAG, "Fetching songs from API");
        AppExecutors.getInstance().diskIO().execute(new Runnable() {
            @Override
            public void run() {
                mSongDAO.deleteAllSongs();
                mSongNetworkDataSource.cargarSongs();
                lastUpdateTimeMillisMap.put("1", System.currentTimeMillis());
            }
        });
    }

    /**
     * Cambiar el id del mutable livedata de una cancion para buscar por su id
     **/
    public void setIdFilterSongs (String idSong) {
        this.idFilterSong.setValue(idSong);
    }

    /**
     * Obtener una cancion por su id en un livedata
     **/
    public LiveData<Song> getSongById() {
        return Transformations.switchMap(idFilterSong, mSongDAO::searchById);
    }


    /**
     * Método que comprueba el inicio de sesión y devuelve el id del usuario en caso de haberla iniciado correctamente.
     * En caso contrario devuelve el valor -1 si es nulo o 0 si introduce una contraseña erronea
     */
    public long checkSession (String username, String password) {
        User user = mUserDAO.searchUserByName(username);
        if (user == null) {// Usuario nulo
            return -1;
        }else {
            if (!user.getPassword().equals(password)) {//Usuario eroneo
                return 0;
            }
            else {// Usuario correcto
                return user.getId();
            }
        }
    }

    /**
     * Insertar usuario si todos los parámetros son válidos y tiene name y email únicos.
     * Expresión regular  para letras minúsculas, puntos y números.
     * Devuelve los valores -3 o -2 si la contraseña o el email son erroneos repectivamente.
     * Devuelve los valores -1 ó 0 si el nombre o el email ya existe repectivamente.
     * Si no inserta  el nuevo usuario y devuelve el id del nuevo usuario
     */
    public long insertUser (User user) {
        Pattern patternEmail = Pattern.compile("^[_A-Za-z0-9-\\+]+(\\.[_A-Za-z0-9-]+)*@[A-Za-z0-9-]+(\\.[A-Za-z0-9]+)*(\\.[A-Za-z]{2,})$");
        Pattern patternPassword = Pattern.compile("^(?=\\w*\\d)(?=\\w*[A-Z])(?=\\w*[a-z])\\S{8,16}$");
        Matcher matcherEmail = patternEmail.matcher(user.getEmail());
        Matcher matcherPassword = patternPassword.matcher(user.getPassword());
        if (!matcherPassword.find()) {//Contraseña erronea con el patron
            return -3;
        }
        else {
            if (!matcherEmail.find()) { //Email erroneo con el patron
                return -2;
            } else {
                if (mUserDAO.searchUserByName(user.getUsername()) != null) {
                    return -1;
                } else {
                    if (mUserDAO.searchUserByEmail(user.getEmail()) != null) {
                        return 0;
                    } else {
                        mUserDAO.insertUser(user);
                        return mUserDAO.searchUserByName(user.getUsername()).getId();
                    }
                }
            }
        }
    }

    /**
     * Modificar el MutableLiveData del usuario según el id
     */
    public void setIdUser(final long id) {
        idFilterUser.setValue(id);
    }

    /**
     * Obtener el live data de un usuaro según su id
     */
    public LiveData<User> getUserById(){
       return Transformations.switchMap(idFilterUser, mUserDAO::searchUserById);
    }

    /**
     * Editar un usuario de la base de datos.
     * Devolvera un valor que corresponddra con un terminado fallo.
     */
    public int editUser (User userEdit) {
        Pattern patternPassword = Pattern.compile("^(?=\\w*\\d)(?=\\w*[A-Z])(?=\\w*[a-z])\\S{8,16}$");
        Matcher matcherPassword = patternPassword.matcher(userEdit.getPassword());
        User auxBD = mUserDAO.searchUserByEmail(userEdit.getEmail());
        if (userEdit.getEmail().equals(auxBD.getEmail())) {//Email correcto
            if (mUserDAO.searchUserByName(userEdit.getUsername()) == null) {//Si no existe un usuario con el username
                if (matcherPassword.find()) {//Contraseña cumple los requerimientos.
                    mUserDAO.update(userEdit);
                    return 1;
                }else {return 0;}
            }else {return -1;}
        }else {return -2;}
    }

    /**
     * Se borra el usuario depues de borrar sus playlist.
     */
    public void deleteUser (long idUser) {
        mPlaylistDAO.deleteAllPlaylistByUser(idUser);
        mUserDAO.deleteUser(idUser);
    }

    /**
     * Añadir una cancion a la playlist.
     */
    public void addPlaylist(Playlist playlist) {
        mPlaylistDAO.insertPlaylist(playlist);
    }

    /**
     * Modificar el mutablelivedata de la playlist por id
     */
    public void setIdPlaylist (String idPlaylist) {
        idFilterPlaylist.setValue(idPlaylist);
    }

    /**
     * Obtener todos las canciones de la playlist de un usuario en un live data
     */
    public LiveData<List<Playlist>> getPlaylistByUser(long idUser) {
        return Transformations.switchMap(idFilterUser, mPlaylistDAO::listAllPlaylistByUser);
    }

    /**
     * Borrar las canciones de la playlist de un usuario
     */
    public void deleteProductShoppingListByUser (String idPlaylist,long idUser) {
        mPlaylistDAO.deletePlaylistByUser(idPlaylist, idUser);
    }

    /**
     * Borra un playlist determinada.
     */
    public void deletePlaylist (Playlist playlist) {
        mPlaylistDAO.deleteSongPlaylist(playlist.getIdPlaylist(),playlist.getIdUser(),playlist.getIdSong());
    }
}