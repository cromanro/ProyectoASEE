package com.example.musicapp.data.network;

import com.example.musicapp.data.GitHubService;
import com.example.musicapp.data.executor.AppExecutors;
import com.example.musicapp.data.executor.OnMusicLoadedListener;
import com.example.musicapp.data.model.Song;

import java.io.IOException;
import java.util.ArrayList;
import java.util.List;

import retrofit2.Call;
import retrofit2.Response;
import retrofit2.Retrofit;
import retrofit2.converter.gson.GsonConverterFactory;

public class MusicNetworkLoaderRunnable implements Runnable {

    private OnMusicLoadedListener mOnMusicLoaded;

    public MusicNetworkLoaderRunnable(OnMusicLoadedListener onMusic) {
        mOnMusicLoaded = onMusic;
    }

    /*
    * Se instancia Retrofit, llamada sincrona, y se indica que use Gson para convertirlo.
    * Se utiliza la url de la api de github, retrofit crea una instancia de la interfaz y se obtiene la lista
    * de canciones mediante un Call que realiza la llamada a la api.
    * Se introduce dentro de un hilo a parte.
    */
    @Override
    public void run() {
        Retrofit retrofit = new Retrofit.Builder().baseUrl("https://raw.githubusercontent.com/").addConverterFactory(GsonConverterFactory.create()).build();
        GitHubService gitHubService = retrofit.create(GitHubService.class);
        Call<List<Song>> call = gitHubService.listSongs();

        /*
         * Se obtiene una respuesta al ejecutar la llamada, y en el caso de que sea nula se crea un nuevo ArrayList
         * y si no  se obtienen los datos de la API.
         */
        try {
            Response<List<Song>> response = call.execute();
            List<Song> songs = response.body() == null ? new ArrayList<>() : response.body();
            AppExecutors.getInstance().mainThread().execute(new Runnable() {
                @Override
                public void run() {
                    mOnMusicLoaded.onSongsLoader(songs);
                }
            });
        } catch (IOException e) {
            e.printStackTrace();
        }
    }
}

