package com.example.musicapp.data.executor;

import com.example.musicapp.data.model.Song;
import java.util.List;

/**
 * Interfaz cuya finalidad es cargar las canciones de la base de datos y
 * devolverlos almacenados en una lista.
 **/
public interface OnMusicLoadedListener {

    void onSongsLoader(List<Song> songs);
}
